module.exports = [
  {
    names: ['eminem', 'marshall mathers', 'slim shady', 'slim'],
    bars: 'shady bars',
    advice: '',
  },
  {
    names: ['kendrick lamar', 'kendrick', 'k dot'],
    bars: 'k dot bars',
    advice: '',
  },
  {
    names: ['busta rhymes', 'busta'],
    bars: 'busta bars',
    advice: '',
  },
  {
    names: ['dr dre', 'doctor dre'],
    bars: 'dr dre bars',
    advice: '',
  },
  {
    names: ['snoop dogg', 'snoop', 'snoop doggy dogg', 'snoop lion'],
    bars: 'snoop dogg bars',
    advice: '',
  },
  {
    names: ['fifty cent', 'fiddy', 'fifty'],
    bars: 'fifty cent bars',
    advice: '',
  },
  {
    names: ['method man', 'meth', 'tiqual'],
    bars: 'method man bars',
    advice: '',
  },
  {
    names: ['wu tang clan', 'wu tang'],
    bars: 'wu tang bars',
    advice: '',
  },
  {
    names: ['biggie', 'notorious b.i.g'],
    bars: 'biggie bars',
    advice: '',
  },
  {
    names: ['2pac', 'tupac'],
    bars: '2pac bars',
    advice: '',
  },
  {
    names: ['j cole', 'jay cole'],
    bars: 'j cole bars',
    advice: '',
  }
];
